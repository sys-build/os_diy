
#include "bootpack.h"
#include <stdio.h>

struct MEMMAN g_memman;

void _start(void)
{
	struct BOOTINFO *binfo = (struct BOOTINFO *) ADR_BOOTINFO;
	char s[40], keybuf[32], mousebuf[128];
	int mx, my, i;
	struct MOUSE_DEC mdec;
    struct MEMMAN *memman = (struct MEMMAN *) &g_memman;


	init_gdtidt();
	init_pic();
	io_sti();
	fifo8_init(&keyfifo, 32, keybuf);
	fifo8_init(&mousefifo, 128, mousebuf);
	io_out8(PIC0_IMR, 0xf9);
	io_out8(PIC1_IMR, 0xef);

	init_keyboard();
	enable_mouse(&mdec);

    unsigned int memtotal = memtest(0x00400000, 0xbfffffff);
    memman_init(memman, 0x00400000, memtotal - 0x00400000);

    struct SHTCTL *shtctl = shtctl_init(memman, binfo->vram, binfo->scrnx, binfo->scrny);

    struct SHEET *sht_back = sheet_alloc(shtctl);
    struct SHEET *sht_mouse = sheet_alloc(shtctl);
    
    struct PIXEL24 buf_mouse[256];
    struct PIXEL24 *buf_back = (struct PIXEL24 *)memman_alloc_4k(memman, 
        binfo->scrnx * binfo->scrny * sizeof(struct PIXEL24));

    sheet_setbuf(sht_back, buf_back, binfo->scrnx, binfo->scrny, -1);
    sheet_setbuf(sht_mouse, buf_mouse, 16, 16, *(int*)&COL24_FF0000);

	init_screen(buf_back, binfo->scrnx, binfo->scrny);
	init_mouse_cursor(buf_mouse, COL24_FF0000);
    sheet_slide(shtctl, sht_back, 0, 0);
	mx = (binfo->scrnx - 16) / 2;
	my = (binfo->scrny - 28 - 16) / 2;
    sheet_slide(shtctl, sht_mouse, mx, my);
	sheet_updown(shtctl, sht_back,  0);
	sheet_updown(shtctl, sht_mouse, 1);

	sprintf(s, "(%3d, %3d)", mx, my);
	draw_string(buf_back, binfo->scrnx, 0, 0, COL24_FFFFFF, s);
	sprintf(s, "memory %dMB   free : %dKB",
			memtotal / (1024 * 1024), memman_total(memman) / 1024);
	draw_string(buf_back, binfo->scrnx, 0, 32, COL24_FFFFFF, s);
    sheet_refresh(shtctl, sht_back, 0, 0, binfo->scrnx, 48);

	for (;;) {
		io_cli();
		if (fifo8_status(&keyfifo) + fifo8_status(&mousefifo) == 0) {
			io_stihlt();
		} else {
			if (fifo8_status(&keyfifo) != 0) {
				i = fifo8_get(&keyfifo);
				io_sti();
				sprintf(s, "%02X", i);
				draw_rect(buf_back, binfo->scrnx, COL24_008484,  0, 16, 15, 31);
				draw_string(buf_back, binfo->scrnx, 0, 16, COL24_FFFFFF, s);
				sheet_refresh(shtctl, sht_back, 0, 16, 16, 32);
			} else if (fifo8_status(&mousefifo) != 0) {
				i = fifo8_get(&mousefifo);
				io_sti();
				if (mouse_decode(&mdec, i) != 0) {
					/* �f�[�^��3�o�C�g�������̂ŕ\�� */
					sprintf(s, "[lcr %4d %4d]", mdec.x, mdec.y);
					if ((mdec.btn & 0x01) != 0) {
						s[1] = 'L';
					}
					if ((mdec.btn & 0x02) != 0) {
						s[3] = 'R';
					}
					if ((mdec.btn & 0x04) != 0) {
						s[2] = 'C';
					}
					draw_rect(buf_back, binfo->scrnx, COL24_008484, 32, 16, 32 + 15 * 8 - 1, 31);
					draw_string(buf_back, binfo->scrnx, 32, 16, COL24_FFFFFF, s);
					sheet_refresh(shtctl, sht_back, 32, 16, 32 + 15 * 8, 32);
					/* �}�E�X�J�[�\���̈ړ� */
					mx += mdec.x;
					my += mdec.y;
					if (mx < 0) {
						mx = 0;
					}
					if (my < 0) {
						my = 0;
					}
					if (mx > binfo->scrnx - 16) {
						mx = binfo->scrnx - 16;
					}
					if (my > binfo->scrny - 16) {
						my = binfo->scrny - 16;
					}
					sprintf(s, "(%3d, %3d)", mx, my);
					draw_rect(buf_back, binfo->scrnx, COL24_008484, 0, 0, 79, 15); /* ���W���� */
					draw_string(buf_back, binfo->scrnx, 0, 0, COL24_FFFFFF, s); /* ���W���� */
					sheet_refresh(shtctl, sht_back, 0, 0, 80, 16);
                    sheet_slide(shtctl, sht_mouse, mx, my);
				}
			}
		}
	}
}



